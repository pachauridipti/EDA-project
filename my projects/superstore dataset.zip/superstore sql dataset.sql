create table prod_dimen( product category varchar(20),
product_sub_category varchar(30), prod_id char(10),
primary key(prod_id));

select* from prod_dimen;
select* from market_fact;
select* from shipping_dimen;
select* from orders_dimen;
select* from customer_dimen;

select customer_name'customer name', customer_segment'customer segment'
from customer_dimen;

select* from customer_dimen
order by cust_id desc;

select order_id,order_date, order_price from 
orders_dimen where order_price = 'high';

select sum(sales),avg(sales)
from market_fact;

select min(sales), max(sales)
from market_fact;

select region, count(cust_id) as 'no_of_customer'
from customer_dimen
group by region
order by count(cust_id);

select prod_id, sum(order_quantity)as 'no_of_product_sold'
from market_fact
group by prod_id
order by sum(order_quantity) desc
limit 1;

select prod_id, sum(order_quantity) as 'no_of_products sold'
from market_fact
group by prod_id
order by sum(order_quantity) desc;

select cust_id,sales
from market_fact
where sales between 1000 and 5000;
