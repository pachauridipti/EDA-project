select* from products;

select productname,quantityperunit
from products;

select productid, productname
from products 
 where UnitsInStock >0;

select productID, productname
from products
where discontinued=1;

select productname, unitprice
from products
order by unitprice desc;

select productid, productname,unitprice
from products
where discontinued=0 and UnitPrice<20
order by UnitPrice;

select productid, productname, unitprice
from products
where UnitPrice between 15 and 25
order by productid;

select productname,unitprice
from products
where unitprice>(select avg(unitprice) from products)
order by UnitPrice;

select distinct productname as ten_expensive_products, unitprice
from products as a
where 20>=(select count(distinct unitprice) from products  as b
where b.UnitPrice>= a.UnitPrice)
order by unitprice desc;

select count(productname),Discontinued
from products 
group by discontinued;

select productname, unitsonorder, unitsinstock
from products
where unitsinstock<QuantityPerUnit;

