select first_name"first name", last_name" last name"from employees;

select distinct department_id from employees;

select* from employees
order by first_name desc;

select first_name, last_name, salary, salary*0.15 pf from employees;

select employee_id, first_name, last_name, salary
from employees
order by salary asc;

select sum(salary) from employees;

select max(salary), min(salary) from employees;

select avg(salary), count(*) from employees;

select count(*) from employees;

select count(distinct job_id) from employees;

select upper(first_name) from employees;

select substring(first_name,1,3) from employees;

select trim(first_name) from employees;

select first_name,last_name , length(first_name)+length(last_name)'length of name' 
from employees;

select* from employees
where first_name
 regexp '[0-9]';

select first_name,last_name,salary
from employees
where salary not between 10000 and 15000;

select first_name, last_name, department_id
from employees
where department_id in (30,100)
order by department_id asc;

select first_name, last_name, salary, department_id
from employees
where (salary not between 10000 and 15000) and (department_id in (30,100));

select first_name,last_name, hire_date
from employees
where year(hire_date) like '1987%';

select first_name 
from employees 
where first_name like '%b%' and first_name like '%c%';

select last_name, job_id,salary
from employees
where job_id in ('it_prog','sh_clerk') and 
salary not in (4500,10000,15000);

select last_name 
from employees 
where length(last_name)=6;

select last_name
from employees
where last_name like '__e%';

select job_id, group_concat(employee_id,' ') 'employees id'
from employees 
group by job_id;

update employees set phone_number = replace(phone_number,'124','999');

select first_name
from employees 
where length(first_name)>=8;

update employees set email= concat(email, '@example.com');

select right(phone_number,4) 'phone no.' 
from employees;

select* from locations;

select* from locations 
where length(street_address)<=(select min(length(street_address))
from locations);

select* from jobs;

select substr(job_title,1)
from jobs;

select first_name, last_name from employees
where instr(last_name,'c')>2;

select first_name "NAME",
length(first_name) "length" from employees
where first_name like 'j%' 
or first_name like 'm%'
or first_name like 'a%'
order by first_name;

select first_name,
lpad(salary,10,'$') 'salary'
from employees;

select left(first_name, 8),
repeat('$',floor(salary/1000))
'salary($)', salary
from employees
order by salary desc;

select employee_id, first_name, last_name, hire_date
from employees
where position("07" in date_format(hire_date,'%d %m %y'));
